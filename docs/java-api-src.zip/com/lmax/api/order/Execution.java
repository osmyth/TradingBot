package com.lmax.api.order;

import com.lmax.api.FixedPointNumber;

/**
 * The results of a pass of the order through the exchange.
 */
public interface Execution
{
    /**
     * The execution id is unique within the scope of a single order book.
     * @return the execution.
     */
    long getExecutionId();

    /**
     * The price at which the execution took place.
     * @return the Price.
     */
    FixedPointNumber getPrice();

    /**
     * The size of execution.
     * @return the quantity.
     */
    FixedPointNumber getQuantity();

    /**
     * The order which the execution effected.  Note that the order object
     * proved by this method is the state of the order at the end of the
     * matching cycle.  It won't the state of the order directly after
     * this execution.  I.e. it doesn't work the same way fix does.
     * @return the order.
     */
    Order getOrder();

    /**
     * The quantity of the order which was cancelled in this execution.
     * @return the Cancelled quantity. 
     */
    FixedPointNumber getCancelledQuantity();
}
