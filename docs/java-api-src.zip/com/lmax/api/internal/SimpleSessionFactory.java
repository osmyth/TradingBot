package com.lmax.api.internal;

import java.util.List;

import com.lmax.api.Session;
import com.lmax.api.account.AccountDetails;

public class SimpleSessionFactory implements SessionFactory
{
    private static final String DELIMITER = "; ";
    private final String urlBase;
    private final String clientIdentifier;

    public SimpleSessionFactory(final String urlBase)
    {
        this(urlBase, null);
    }

    public SimpleSessionFactory(final String urlBase, final String clientIdentifier)
    {
        this.urlBase = urlBase;
        this.clientIdentifier = clientIdentifier;
    }

    public Session createSession(final Response response, final AccountDetails accountDetails)
    {
        final List<String> cookies = response.getHeaderByName("Set-Cookie");
        StringBuilder builder = new StringBuilder();

        for (String cookie : cookies)
        {
            builder.append(extractCookiePair(cookie));
            builder.append(DELIMITER);
        }
        builder.delete(builder.length() - DELIMITER.length(), builder.length());

        final String jSessionId = builder.toString();

        final ConnectionFactory connectionFactory = new ConnectionFactory(urlBase, clientIdentifier, jSessionId);

        return new SessionImpl(connectionFactory, accountDetails, urlBase);
    }

    private String extractCookiePair(String cookie)
    {
        int index = cookie.indexOf(';');
        return (index != -1) ? cookie.substring(0, index) : cookie;
    }
}
