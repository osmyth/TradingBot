package com.lmax.api.internal.protocol;


import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.SequenceInputStream;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class EventStreamHandler
{
    private final SAXParserFactory saxParserFactory;
    private final DefaultHandler saxParserHelper;
    
    public EventStreamHandler(final DefaultHandler helper)
    {
        this(helper, SAXParserFactory.newInstance());
    }

    // @ExposedForTesting
    protected EventStreamHandler(final DefaultHandler helper, final SAXParserFactory saxParserFactory)
    {
        this.saxParserHelper = helper;
        this.saxParserFactory = saxParserFactory;
    }

    public void parseEventStream(InputStream inputStream) throws IOException, SAXException
    {
        SAXParser saxParser;
        try
        {
            saxParser = saxParserFactory.newSAXParser();

            InputStream headWrapper = new SequenceInputStream(new ByteArrayInputStream("<o>".getBytes()), inputStream);
            InputStream tailWrapper = new ByteArrayInputStream("</o>".getBytes());
            SequenceInputStream wrappedInputStream = new SequenceInputStream(headWrapper, tailWrapper);

            saxParser.parse(new InputSource(wrappedInputStream), saxParserHelper);
        }
        catch (ParserConfigurationException e)
        {
            throw new IllegalStateException(e);
        }
    }
}
