package com.lmax.api.internal.events;

import com.lmax.api.FixedPointNumber;
import java.util.Map;

import com.lmax.api.account.AccountStateEvent;

public class AccountStateEventImpl implements AccountStateEvent
{
    private final long accountId;
    private final FixedPointNumber balance;
    private final FixedPointNumber availableFunds;
    private final FixedPointNumber availableToWithdraw;
    private final FixedPointNumber unrealisedProfitAndLoss;
    private final FixedPointNumber margin;
    private final Map<String, FixedPointNumber> walletByCurrency;

    public AccountStateEventImpl(long accountId, FixedPointNumber balance, FixedPointNumber availableFunds, FixedPointNumber availableToWithdraw,
                                 FixedPointNumber unrealisedProfitAndLoss, FixedPointNumber margin,
                                 Map<String, FixedPointNumber> walletByCurrency)
    {
        this.accountId = accountId;
        this.balance = balance;
        this.availableFunds = availableFunds;
        this.availableToWithdraw = availableToWithdraw;
        this.unrealisedProfitAndLoss = unrealisedProfitAndLoss;
        this.margin = margin;
        this.walletByCurrency = walletByCurrency;
    }


    @Override
    public long getAccountId()
    {
        return accountId;
    }

    @Override
    public FixedPointNumber getBalance()
    {
         return balance;
    }

    @Override
    public FixedPointNumber getAvailableFunds()
    {
         return availableFunds;
    }

    @Override
    public FixedPointNumber getAvailableToWithdraw()
    {
         return availableToWithdraw;
    }

    @Override
    public FixedPointNumber getUnrealisedProfitAndLoss()
    {
         return unrealisedProfitAndLoss;
    }

    @Override
    public FixedPointNumber getMargin()
    {
         return margin;
    }

    @Override
    public Map<String, FixedPointNumber> getWallets()
    {
         return walletByCurrency;
    }

    @Override
    public boolean equals(final Object o)
    {
        if (this == o)
        { return true; }
        if (o == null || getClass() != o.getClass())
        { return false; }

        final AccountStateEventImpl that = (AccountStateEventImpl)o;

        if (accountId != that.accountId)
        { return false; }
        if (availableFunds != null ? !availableFunds.equals(that.availableFunds) : that.availableFunds != null)
        { return false; }
        if (availableToWithdraw != null ? !availableToWithdraw.equals(that.availableToWithdraw) : that.availableToWithdraw != null)
        { return false; }
        if (balance != null ? !balance.equals(that.balance) : that.balance != null)
        { return false; }
        if (margin != null ? !margin.equals(that.margin) : that.margin != null)
        { return false; }
        if (unrealisedProfitAndLoss != null ? !unrealisedProfitAndLoss.equals(that.unrealisedProfitAndLoss) : that.unrealisedProfitAndLoss != null)
        { return false; }
        if (walletByCurrency != null ? !walletByCurrency.equals(that.walletByCurrency) : that.walletByCurrency != null)
        { return false; }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = (int)(accountId ^ (accountId >>> 32));
        result = 31 * result + (balance != null ? balance.hashCode() : 0);
        result = 31 * result + (availableFunds != null ? availableFunds.hashCode() : 0);
        result = 31 * result + (availableToWithdraw != null ? availableToWithdraw.hashCode() : 0);
        result = 31 * result + (unrealisedProfitAndLoss != null ? unrealisedProfitAndLoss.hashCode() : 0);
        result = 31 * result + (margin != null ? margin.hashCode() : 0);
        result = 31 * result + (walletByCurrency != null ? walletByCurrency.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "AccountStateEventImpl{" +
               "accountId=" + accountId +
               ", balance=" + balance +
               ", availableFunds=" + availableFunds +
               ", availableToWithdraw=" + availableToWithdraw +
               ", unrealisedProfitAndLoss=" + unrealisedProfitAndLoss +
               ", margin=" + margin +
               ", walletByCurrency=" + walletByCurrency +
               '}';
    }
}
