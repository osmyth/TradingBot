package com.lmax.api.internal;


import java.util.List;
import java.util.Map;

public class Response
{
    public static final int HTTP_OK = 200;

    public enum Status
    {
        OK,
        FAIL
    }

    private int httpStatusCode;
    private String messagePayload;
    private Map<String, List<String>> headers;

    public Response(final int httpStatusCode, final String messagePayload, final Map<String, List<String>> headers)
    {
        this.httpStatusCode = httpStatusCode;
        this.messagePayload = messagePayload;
        this.headers = headers;
    }

    public int getHttpStatusCode()
    {
        return httpStatusCode;
    }

    public String getMessagePayload()
    {
        return messagePayload;
    }

    public Status getStatus()
    {
        return httpStatusCode == HTTP_OK ? Status.OK : Status.FAIL;
    }

    public String toString()
    {
        return "Response{" +
               "httpStatusCode=" + httpStatusCode +
               ", messagePayload='" + messagePayload + '\'' +
               ", headers=" + headers +
               '}';
    }

    public List<String> getHeaderByName(String headerName)
    {
        String lowerCaseHeaderName = headerName.toLowerCase();
        for(String key: headers.keySet())
        {
            if(key != null && key.toLowerCase().equals(lowerCaseHeaderName))
            {
                return headers.get(key);
            }
        }
        return null;
    }
}
