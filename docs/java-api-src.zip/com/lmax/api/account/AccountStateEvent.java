package com.lmax.api.account;

import com.lmax.api.FixedPointNumber;
import java.util.Map;

/**
 * A event that contains all of the top level information about an account's
 * current state.
 */
public interface AccountStateEvent
{
    /**
     * Get the account id that this event pertains to.
     * @return  account id
     */
    long getAccountId();

    /**
     * Get the accounts current balance.
     * @return account balance
     */
    FixedPointNumber getBalance();

    /**
     * Get the account's available funds.
     * @return available funds
     */
    FixedPointNumber getAvailableFunds();

    /**
     * Get the amount that this account is available to withdraw.
     * @return available to withdraw
     */
    FixedPointNumber getAvailableToWithdraw();

    /**
     * Get a signed amount that is the account's unrealised profit (or loss).
     * @return unrealised profit (or loss)
     */
    FixedPointNumber getUnrealisedProfitAndLoss();

    /**
     * Get the account's total margin.
     * @return margin
     */
    FixedPointNumber getMargin();

    /**
     * Get the account's balances by currency.  The map is keyed by
     * 3 letter currency symbol, e.g. GBP.
     * @return map of currency code to wallet balance
     */
    Map<String, FixedPointNumber> getWallets();
}
